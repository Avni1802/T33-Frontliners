const hidePage = `body > :not(.msg) {
        display:none;

}

`

function listen
